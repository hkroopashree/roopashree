package com.qa.zerobank.testcases;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qa.zerobank.base.BaseTest;
import com.qa.zerobank.pages.AccountSummaryPage;
import com.qa.zerobank.pages.FundTransferPages;
import com.qa.zerobank.pages.HomePage;
import com.qa.zerobank.pages.LogInPage;
import com.qa.zerobank.pages.PayBillsPage;
import com.qa.zerobank.util.TestUtil;

public class FundTransferTestCases extends BaseTest {
	HomePage homePage;
	LogInPage logInPage;
	AccountSummaryPage accountSummaryPage;
	TestUtil testUtil;
	FundTransferPages FundTransferPage;
	
	   // constructor
    public FundTransferTestCases() {
    	super();
    }
    
    @BeforeMethod
    public void setUp() {
    	initialization();
    	homePage = new HomePage();
    	logInPage = new LogInPage();
    	accountSummaryPage = new AccountSummaryPage();
    	testUtil = new TestUtil();
    	FundTransferPage = new FundTransferPages();
    }
    
    @AfterMethod
    public void cleanUp() {
    	TestUtil.takeScreenshotAtEndOfTest("HomePage");
    	driver.close();
    	driver.quit();
    	
    }
    

    
    @Test
    public void foreignCurrencyCheck() {
    	logInPage = homePage.clickOnSignInButton();
    	accountSummaryPage = logInPage.logIn();
    	accountSummaryPage.assertAccountSummaryPageTitle();
    	FundTransferPage = accountSummaryPage.fundTransferFn();
    	FundTransferPage.assertFundTitle();
    	FundTransferPage.fundTransfer();
    }

}
