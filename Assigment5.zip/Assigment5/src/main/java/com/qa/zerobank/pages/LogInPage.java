package com.qa.zerobank.pages;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.zerobank.base.BaseTest;

public class LogInPage extends BaseTest {
	//Object Repository
	@FindBy(id = "user_login")
	WebElement lusername;
	@FindBy(name = "user_password")
	WebElement lpassword;
	@FindBy(className  = "icon-question-sign")
	WebElement questionmark;
	@FindBy(css  = "[name = 'user_remember_me']")
	WebElement signincheckbox;
	@FindBy(name = "submit")
	WebElement signinbutton;
	@FindBy(partialLinkText = "Forgot your")
	WebElement forgotpassword;
	@FindBy(id = "details-button")
	WebElement detailsbutton;
	@FindBy(partialLinkText = "Proceed to zero.webapp")
	WebElement proceedtolink;
	@FindBy(xpath = "//div[contains(text(),'Login and/or password are wrong.')]")
	WebElement invalidLogin;
	
	//Initializing page Objects
	public LogInPage() {
		PageFactory.initElements(driver, this);
	}
	
	public void assertLoginPageTitle() {
		assertEquals(driver.getTitle(),"Zero - Log in");
		
	}

	public AccountSummaryPage logIn() {
		lusername.sendKeys(prop.getProperty("userid"));
		lpassword.sendKeys(prop.getProperty("password"));
		signinbutton.click();
		detailsbutton.click();
		proceedtolink.click();
		
		return new AccountSummaryPage();
		
	}

	public void invalidLogIn() {
		lusername.sendKeys(prop.getProperty("userIdInvalid"));
		lpassword.sendKeys(prop.getProperty("passwordInvalid"));
		signinbutton.click();
		assertEquals(invalidLogin.getText(), "Login and/or password are wrong.");
		
	}
	
}
