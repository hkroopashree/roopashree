package com.qa.zerobank.pages;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.zerobank.base.BaseTest;

public class AccountSummaryPage extends BaseTest{

	
	//Initializing page Objects
    @FindBy(id="account_activity_tab") WebElement account_activity_tab;
    @FindBy(id="transfer_funds_tab") WebElement transfer_funds_tab;
    @FindBy(id="pay_bills_tab") WebElement pay_bills_tab;
    @FindBy(id="money_map_tab") WebElement money_map_tab;
    @FindBy(id="online_statements_tab") WebElement online_statements_tab;
	@FindBy(partialLinkText = "Pay Bil")
	WebElement payBill;
	@FindBy(xpath = "//a[contains(text(),'Transfer Funds')]")
	WebElement transferFunds;
		   // constructor
	    public AccountSummaryPage() {
	        PageFactory.initElements(driver, this);
	    }

	    // assert title
	    public void assertAccountSummaryPageTitle() {
	        assertEquals(driver.getTitle(), "Zero - Account Summary");
	    }
		public PayBillsPage paybillsFn() {
			 payBill.click();
			return new PayBillsPage();
		}
		
		public FundTransferPages fundTransferFn() {
			transferFunds.click();
			return new FundTransferPages();
		}
		
}
