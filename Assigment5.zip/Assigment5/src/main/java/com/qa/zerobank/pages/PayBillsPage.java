package com.qa.zerobank.pages;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.zerobank.base.BaseTest;

public class PayBillsPage extends BaseTest {
		@FindBy(xpath = "//a[contains(@href ,'#ui-tabs-3')]")
		WebElement foreignCurrency;
		@FindBy(id = "purchase_cash")
		WebElement purchaseCash;
		@FindBy(id = "pay_saved_payees")
		WebElement paySavedPayeePayBtn;
		@FindBy(xpath = "//h2[contains(text(),'Make payments to your saved payees')]")
		WebElement headerPaySavedPayee;
		@FindBy(xpath = "//h2[contains(text(),'Who are you paying?')]")
		WebElement headerAddPayee;
		@FindBy (id = "add_new_payee")
		WebElement addNewPayeePayBtn;
		@FindBy(linkText = "Add New Payee")
		WebElement addNewPayee;
		public PayBillsPage() {
			PageFactory.initElements(driver, this);
		}
		
		public void assertPayBillTitle() {
			 
			  assertEquals(driver.getTitle(), "Zero - Pay Bills");
		}
		
		public void foreignCurrencyWithEmptyValue() {
		      foreignCurrency.click();
		      purchaseCash.click();
		      Alert purchaseAlert = driver.switchTo().alert();
		      String alertText = purchaseAlert.getText();
		      System.out.println("The text on the Alert box is -'"+ alertText +"'");
		      assertEquals(alertText,"Please, ensure that you have filled all the required fields with valid values.");
		      purchaseAlert.accept();
			
		}
		
		public void  invalidPaySavedPayees() {
			
		      paySavedPayeePayBtn.click();
		      String headerText = headerPaySavedPayee.getText();
		      assertEquals(headerText,"Make payments to your saved payees");
		      
			
		}
		
		public void  invalidAddPayee() {
			  addNewPayee.click();
			  addNewPayeePayBtn.click();
		      String headerText = headerAddPayee.getText();
		      assertEquals(headerText,"Who are you paying?");
		      
			
		}
		
		public void invalidForeignCurrency() {
		      foreignCurrency.click();
		      purchaseCash.click();
		      Alert purchaseAlert = driver.switchTo().alert();
		      String alertText = purchaseAlert.getText();
		      System.out.println("The text on the Alert box is -'"+ alertText +"'");
		      assertEquals(alertText,"Please, ensure that you have filled all the required fields with valid values.");
		      purchaseAlert.accept();
			
		}
		
}
