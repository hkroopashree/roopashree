package com.qa.zerobank.testcases;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qa.zerobank.base.BaseTest;
import com.qa.zerobank.pages.AccountSummaryPage;
import com.qa.zerobank.pages.FundTransferPages;
import com.qa.zerobank.pages.HomePage;
import com.qa.zerobank.pages.LogInPage;
import com.qa.zerobank.pages.PayBillsPage;
import com.qa.zerobank.util.TestUtil;

public class NegativeTestCases extends BaseTest {

	HomePage homePage;
	LogInPage logInPage;
	AccountSummaryPage accountSummaryPage;
	TestUtil testUtil;
	FundTransferPages fundTransferPage;
	PayBillsPage payBillsPage;
	// constructor
    public NegativeTestCases() {
    	super();
    }
    
    @BeforeMethod
    public void setUp() {
    	initialization();
    	homePage = new HomePage();
    	logInPage = new LogInPage();
    	payBillsPage = new PayBillsPage();
    	accountSummaryPage = new AccountSummaryPage();
//    	testUtil = new TestUtil();
    }
    
    @AfterMethod
    public void cleanUp() {
    	TestUtil.takeScreenshotAtEndOfTest("HomePage");
    	driver.close();
    	driver.quit();
    	
    }
    
  //Handling invalid data for Login functionality
    @Test
    public void validateInvalidLoginFunctionality() {
    	logInPage = homePage.clickOnSignInButton();
    	logInPage.invalidLogIn();
    }
    //Handling the Invalid data for Fund Transfer
    @Test
    public void validateInvalidFundTransfer() {
    	logInPage = homePage.clickOnSignInButton();
    	accountSummaryPage = logInPage.logIn();
    	accountSummaryPage.assertAccountSummaryPageTitle();
    	fundTransferPage = accountSummaryPage.fundTransferFn();
    	fundTransferPage.assertFundTitle();
    	fundTransferPage.invalidFundTransfer();
    }
    
    //Handling the Invalid  data for Pay saved payee
    @Test
    public void validateInvalidPaySavedPayee() {
    	logInPage = homePage.clickOnSignInButton();
    	accountSummaryPage = logInPage.logIn();
    	accountSummaryPage.assertAccountSummaryPageTitle();
    	payBillsPage = accountSummaryPage.paybillsFn();
    	payBillsPage.assertPayBillTitle();
    	payBillsPage.invalidPaySavedPayees();
    }
    
    //Handling the invalid data for Add new payee
    @Test
    public void validateInvalidAddNewPayee() {
    	logInPage = homePage.clickOnSignInButton();
    	accountSummaryPage = logInPage.logIn();
    	accountSummaryPage.assertAccountSummaryPageTitle();
    	payBillsPage = accountSummaryPage.paybillsFn();
    	payBillsPage.assertPayBillTitle();
    	payBillsPage.invalidAddPayee();
    }
    
    //Invalid Foreign currency handling test case
    @Test
    public void ValidateInvalidForeignCurrency() {
    	logInPage = homePage.clickOnSignInButton();
    	accountSummaryPage = logInPage.logIn();
    	accountSummaryPage.assertAccountSummaryPageTitle();
    	payBillsPage = accountSummaryPage.paybillsFn();
    	payBillsPage.assertPayBillTitle();
    	payBillsPage.invalidForeignCurrency();
    }
    
  
}
