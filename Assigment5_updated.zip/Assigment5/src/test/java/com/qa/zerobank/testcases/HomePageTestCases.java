package com.qa.zerobank.testcases;

import static org.testng.Assert.assertTrue;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.zerobank.base.BaseTest;
import com.qa.zerobank.base.BaseTest;
import com.qa.zerobank.pages.HomePage;
import com.qa.zerobank.pages.LogInPage;
import com.qa.zerobank.util.TestUtil;


public class HomePageTestCases extends BaseTest{
	HomePage homePage;
	LogInPage logInPage;
	TestUtil testUtil;
	String sheetName = "Search";
	   // constructor
    public HomePageTestCases() {
    	super();
    }
    
    @BeforeMethod
    public void setUp() {
    	initialization();
    	homePage = new HomePage();
    	logInPage = new LogInPage();
    	testUtil = new TestUtil();
    }
    
    @AfterMethod
    public void cleanUp() {
    	TestUtil.takeScreenshotAtEndOfTest("HomePage");
    	driver.close();
    	driver.quit();   	
    }
    
    @Test
    public void validateHomePage() {
    	homePage.assertHomePageTitle();
    }
    
    @Test
    public void validateLogo() {
    	assertTrue(homePage.validateBrandLogo());
    }
    
    @Test
    public void signButtonTest() {
    	logInPage = homePage.clickOnSignInButton();
    	logInPage.assertLoginPageTitle();
    }

}
