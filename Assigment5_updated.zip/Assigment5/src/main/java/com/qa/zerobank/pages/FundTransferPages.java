package com.qa.zerobank.pages;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.qa.zerobank.base.BaseTest;

public class FundTransferPages extends BaseTest {

	@FindBy(id = "tf_fromAccountId" )
	WebElement fromAccount;
	@FindBy(id = "tf_toAccountId")
	WebElement toAccount;
	@FindBy(id = "tf_amount")
	WebElement amount;
	@FindBy(id = "tf_description")
	WebElement description;
	@FindBy(id ="btn_submit")
	WebElement submit;
	@FindBy(xpath = "//h2[contains(text(),'Transfer Money & Make Payments - Verify')]")
	WebElement transferMoney;
	@FindBy(xpath ="//div[contains(text(),'You successfully submitted your transaction.')]")
	WebElement successMsg;
	@FindBy(xpath = "//h2[contains(text(),'Transfer Money & Make Payments')]")
	WebElement Transfer1;
	
	public FundTransferPages() {
		PageFactory.initElements(driver, this);
	}
	
	public void assertFundTitle() {
		  assertEquals(driver.getTitle(), "Zero - Transfer Funds");
	}
	
	public void fundTransfer() {
    Select sel = new Select(fromAccount);     
    sel.selectByVisibleText("Savings(Avail. balance = $ 1548)");
    Select sel1 = new Select(toAccount);     
    sel1.selectByValue("2");
    amount.sendKeys("123");
    description.sendKeys("Savings for future");
    submit.click();
    String header = transferMoney.getText();
    assertEquals(header, "Transfer Money & Make Payments - Verify");
    submit.click();
    assertEquals(successMsg.getText(), "You successfully submitted your transaction.");
	}
	
	public void invalidFundTransfer() {
	    
	    submit.click();
	    String header1 = Transfer1.getText();
	    assertEquals(header1, "Transfer Money & Make Payments");
		}
		
		
	
}
