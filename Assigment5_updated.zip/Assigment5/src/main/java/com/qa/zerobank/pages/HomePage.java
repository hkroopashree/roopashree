package com.qa.zerobank.pages;

import static org.testng.Assert.assertEquals;

import org.apache.tools.ant.property.GetProperty;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.zerobank.base.BaseTest;

public class HomePage extends BaseTest{
	//Object Repository
	@FindBy(id = "signin_button")
	WebElement signInButton;
	@FindBy(name = "searchTerm")
	WebElement searchBox;
	@FindBy(className  = "brand")
	WebElement brandLogo;
	@FindBy(id  = "onlineBankingMenu")
	WebElement onlineBankingLink;
	@FindBy(linkText = "Feedback")
	WebElement feedbackLink;
	@FindBy(partialLinkText = "More Servic")
	WebElement moreServicesLink;
	@FindBy(partialLinkText = "https://www.microfoc")
	WebElement microFocusLink;
	@FindBy(id = "account_activity_link")
	WebElement checkAccActivity;
	@FindBy(id = "transfer_funds_link")
	WebElement transferFunds;	
	@FindBy(id = "money_map_link")
	WebElement moneyMapLink;

	
	
	public HomePage() {
		PageFactory.initElements(driver, this);
	}
	
	public void assertHomePageTitle() {
		assertEquals(driver.getTitle(),"Zero - Personal Banking - Loans - Credit Cards");
	}
	
	public boolean validateBrandLogo() {
		return brandLogo.isDisplayed();
	}
	

	public LogInPage clickOnSignInButton() {
		signInButton.click();
		return new LogInPage();
	}
	
	
}
