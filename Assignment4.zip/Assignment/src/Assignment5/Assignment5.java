package Assignment5;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.BeforeClass;

import static org.testng.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.AfterSuite;

public class Assignment5 {
	public WebDriver driver;
	public Actions act;

  @Test(dataProvider = "dp", groups = {"Smoke"} )
  public void login(String user, String pass) {
		// Login Test
	  driver.findElement(By.id("signin_button")).click();
	  driver.findElement(By.name("user_login")).sendKeys(user);
	  driver.findElement(By.name("user_password")).sendKeys(pass);
	  driver.findElement(By.name("submit")).click();
	  try{if (driver.findElement(By.id("details-button")).isDisplayed()) {
		  driver.findElement(By.id("details-button")).click();
		  driver.findElement(By.id("proceed-link")).click();
	  }
	  }catch(Exception e) {
	  }
	  assertEquals(driver.getTitle(), "Zero - Account Summary");
	  driver.findElement(By.partialLinkText("Pay Bil")).click();
      driver.findElement(By.xpath("//a[contains(@href ,'#ui-tabs-3')]")).click();
      driver.findElement(By.id("purchase_cash")).click();
      Alert purchaseAlert = driver.switchTo().alert();
      String alertText = purchaseAlert.getText();
      System.out.println("The text on the Alert box is -'"+ alertText +"'");
      assertEquals(alertText,"Please, ensure that you have filled all the required fields with valid values.");
      purchaseAlert.accept();
  }
  @Test(dataProvider = "dp", groups = {"Smoke"})
  public void fundTransfer(String user, String pass) {
		// Login Test
	  driver.findElement(By.id("signin_button")).click();
	  driver.findElement(By.name("user_login")).sendKeys(user);
	  driver.findElement(By.name("user_password")).sendKeys(pass);
	  driver.findElement(By.name("submit")).click();
	  try{if (driver.findElement(By.id("details-button")).isDisplayed()) {
		  driver.findElement(By.id("details-button")).click();
		  driver.findElement(By.id("proceed-link")).click();
	  }
	  }catch(Exception e) {
		  
	  }
	  assertEquals(driver.getTitle(), "Zero - Account Summary");
	  driver.findElement(By.xpath("//a[contains(text(),'Transfer Funds')]")).click();
	  
	  WebElement fromAccount = driver.findElement(By.id("tf_fromAccountId"));
      Select sel = new Select(fromAccount);     
      sel.selectByVisibleText("Savings(Avail. balance = $ 1548)");
    
      WebElement toAccount = driver.findElement(By.id("tf_toAccountId"));
      Select sel1 = new Select(toAccount);     
      sel1.selectByValue("2");
      driver.findElement(By.id("tf_amount")).sendKeys("123");
      driver.findElement(By.id("tf_description")).sendKeys("Savings for future");
      driver.findElement(By.id("btn_submit")).click();
      String header = driver.findElement(By.xpath("//h2[contains(text(),'Transfer Money & Make Payments - Verify')]")).getText();
      assertEquals(header, "Transfer Money & Make Payments - Verify");
      driver.findElement(By.id("btn_submit")).click();
      assertEquals(driver.findElement(By.xpath("//div[contains(text(),'You successfully submitted your transaction.')]")).getText(), "You successfully submitted your transaction.");
  }
 //Negative 5
  @Test(dataProvider = "dp1",groups = {"Regression"})
  public void loginWithWrongValues(String user, String pass) {
	  driver.findElement(By.id("signin_button")).click();
	  driver.findElement(By.name("user_login")).sendKeys(user);
	  driver.findElement(By.name("user_password")).sendKeys(pass);
	  driver.findElement(By.name("submit")).click();
	  assertEquals(driver.findElement(By.xpath("//div[contains(text(),'Login and/or password are wrong.')]")).getText(), "Login and/or password are wrong.");
	  
	  driver.findElement(By.name("user_login")).sendKeys("username");
	  driver.findElement(By.name("user_password")).sendKeys("password");
	  driver.findElement(By.name("submit")).click();
	  try{if (driver.findElement(By.id("details-button")).isDisplayed()) {
		  driver.findElement(By.id("details-button")).click();
		  driver.findElement(By.id("proceed-link")).click();
	  }
	  }catch(Exception e) {
	  }
	  assertEquals(driver.getTitle(), "Zero - Log in","Login Failed !");
	  
  }
 
	
//1 negative fund transfer 
	@Test(dataProvider = "dp",groups = {"Regression"})
	public void fundTransferWrongValues(String user, String pass) throws InterruptedException {
			// Login Test
	  driver.findElement(By.id("signin_button")).click();
	  driver.findElement(By.name("user_login")).sendKeys(user);
	  driver.findElement(By.name("user_password")).sendKeys(pass);
	  driver.findElement(By.name("submit")).click();
	  try{if (driver.findElement(By.id("details-button")).isDisplayed()) {
		  driver.findElement(By.id("details-button")).click();
		  driver.findElement(By.id("proceed-link")).click();
	  }
	  }catch(Exception e) {
	  }
	  assertEquals(driver.getTitle(), "Zero - Account Summary");
	  driver.findElement(By.xpath("//a[contains(text(),'Transfer Funds')]")).click();
	  driver.findElement(By.id("btn_submit")).click();
	  assertEquals(driver.getTitle(), "Zero - Account Summary");
	  assertEquals(driver.findElement(By.xpath("//div[contains(text(),'You successfully submitted your transaction.')]")).getText(), "You successfully submitted your transaction.","Test Failed for negative fund transaction");
	 

	}
	  	
	//2 negative with foreign currency 
	@Test(dataProvider = "dp",groups = {"Regression"})
	public void foreignCurrency(String user, String pass) {
		// Login Test
	  driver.findElement(By.id("signin_button")).click();
	  driver.findElement(By.name("user_login")).sendKeys(user);
	  driver.findElement(By.name("user_password")).sendKeys(pass);
	  driver.findElement(By.name("submit")).click();
	  try{if (driver.findElement(By.id("details-button")).isDisplayed()) {
		  driver.findElement(By.id("details-button")).click();
		  driver.findElement(By.id("proceed-link")).click();
	  }
	  }catch(Exception e) {
	  }
	  assertEquals(driver.getTitle(), "Zero - Account Summary");
      driver.findElement(By.partialLinkText("Pay Bil")).click();
      driver.findElement(By.xpath("//a[contains(@href ,'#ui-tabs-3')]")).click();
      driver.findElement(By.id("purchase_cash")).click();
      Alert purchaseAlert = driver.switchTo().alert();
      String alertText = purchaseAlert.getText();
      purchaseAlert.accept();
      assertEquals(alertText, "Please, ensure that you have filled all the required fields with valid values.");
      assertEquals(driver.findElement(By.id("//div[@id='alert_content']")).getText(),"Foreign currency cash was successfully purchased.","Test Failed !!");
      
	  }
	 
//negative 3 -- pay saved payee
	@Test(dataProvider = "dp",groups = {"Regression"})
	public void paySavedPayees(String user, String pass) {
		// Login Test
	  driver.findElement(By.id("signin_button")).click();
	  driver.findElement(By.name("user_login")).sendKeys(user);
	  driver.findElement(By.name("user_password")).sendKeys(pass);
	  driver.findElement(By.name("submit")).click();
	  try{if (driver.findElement(By.id("details-button")).isDisplayed()) {
		  driver.findElement(By.id("details-button")).click();
		  driver.findElement(By.id("proceed-link")).click();
	  }
	  }catch(Exception e) {
	  }
	  assertEquals(driver.getTitle(), "Zero - Account Summary");
      driver.findElement(By.partialLinkText("Pay Bil")).click();
      driver.findElement(By.id("pay_saved_payees")).click();
      assertEquals(driver.findElement(By.xpath("//span[contains(text(),'The payment was successfully submitted.')]")),"The payment was successfully submitted.","Test Failed!");
      
	}
	
//	// negative 4 
	@Test(dataProvider = "dp",groups = {"Regression"})
	public void addNewPayee(String user, String pass) {
		// Login Test
	  driver.findElement(By.id("signin_button")).click();
	  driver.findElement(By.name("user_login")).sendKeys(user);
	  driver.findElement(By.name("user_password")).sendKeys(pass);
	  driver.findElement(By.name("submit")).click();
	  try{if (driver.findElement(By.id("details-button")).isDisplayed()) {
		  driver.findElement(By.id("details-button")).click();
		  driver.findElement(By.id("proceed-link")).click();
	  }
	  }catch(Exception e) {
	  }
	  assertEquals(driver.getTitle(), "Zero - Account Summary");
      driver.findElement(By.partialLinkText("Pay Bil")).click();
      driver.findElement(By.xpath("//a[contains(text(),'Add New Payee')]")).click();
      driver.findElement(By.id("add_new_payee")).click();
      assertEquals(driver.findElement(By.id("alert_content")).getText(),"The new payee was successfully created.","Test Failed in New payee");
      
	}
	
  @BeforeMethod(alwaysRun = true)
  public void beforeMethod() {
	  assertEquals(driver.getTitle(), "Zero - Personal Banking - Loans - Credit Cards");
	   
  }

  @AfterMethod(alwaysRun = true)
  public void logOut() {
	  driver.findElement(By.xpath("(//*[@class = 'dropdown-toggle'])[2]")).click();
	  driver.findElement(By.xpath("//a[@id='logout_link']")).click();

  }


  @DataProvider
  public Object[][] dp() {
    return new Object[][] {
      new Object[] { "username", "password" },
     // new Object[] { 2, "password" },
    };
  }
  
  @DataProvider
  public Object[][] dp1() {
    return new Object[][] {
      new Object[] { "user", "pass" },

    };
  }
  @BeforeClass(alwaysRun = true)
  public void beforeClass() {
	  assertEquals(driver.getTitle(), "Zero - Personal Banking - Loans - Credit Cards");
  }

  @AfterClass(alwaysRun = true)
  public void afterClass() {
	  assertEquals(driver.getTitle(), "Zero - Personal Banking - Loans - Credit Cards");
  }

  @BeforeTest(alwaysRun = true)
  public void setUp() {
	  System.setProperty("webdriver.chrome.driver","C:\\SeleniumBrowserDrivers\\chromedriver.exe");		
	  driver = new ChromeDriver();       
	  driver.manage().window().maximize();      
	  driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	  driver.get("http://zero.webappsecurity.com/");
	  act = new Actions(driver);
  }

  @AfterTest(alwaysRun = true)
  public void cleanUp() {
	  driver.close();
	  driver.quit();
  }

  @BeforeSuite(alwaysRun = true)
  public void beforeSuite() {
	  System.out.println("Execution of Suite starts");  
  }

  @AfterSuite(alwaysRun = true)
  public void afterSuite() {
	  System.out.println("Execution ends");
  }

}
